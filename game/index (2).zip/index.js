const heading = document.querySelector('.heading');
const resetBtn = document.querySelector('.reset-btn');

var gamecells = document.getElementsByClassName('cell');
console.log(gamecells);







